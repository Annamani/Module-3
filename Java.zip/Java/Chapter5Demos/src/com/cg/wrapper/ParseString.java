package com.cg.wrapper;

import java.util.Scanner;

public class ParseString {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner scanner = new Scanner("1,2,3,4,5,6,7,8").useDelimiter(",");
		while (scanner.hasNextInt()) {
			int num = scanner.nextInt();
			if (num % 2 == 0) {
				System.out.println(num);
			}
		}
		scanner.close();
	}


}
